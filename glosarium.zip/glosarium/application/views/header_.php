<?php //main header ?>

<div class="container">
	<h1 class="text-left"><img src="<?php echo base_url('add_lib/img/glosarium2.png')?>"/></h1><hr/>
</div>