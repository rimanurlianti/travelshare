<?php //main footer ?>

<div class="container">
	<hr/>
	<p class="text-left"><img src="<?php echo base_url('add_lib/img/glosarium_FN.png')?>"/></p>
</div>