<?php //master search box ?>

<div class="container">
	<div class="row" id="mainsbox">
		<div class="col-xs-2"></div>
		<div class="col-xs-6 col-xs-offset-1">
			<form action="<?php echo base_url()?>search/" method="POST" role="search">
				<div class="input-group">
					<input class="form-control" placeholder="Search . . ." name="srch-term" id="ed-srch-term" type="text">
					<div class="input-group-btn">
						<button type="submit" id="searchbtn"></button>
					</div>
				</div>
			</form>
		</div>
	</div>
</div>