<?php //master search box ?>

<div class="container">
	<!-- result set rendering -->
	<!-- pagination -->
	<?php 
		print_r($sresult);
	?>
	
</div>