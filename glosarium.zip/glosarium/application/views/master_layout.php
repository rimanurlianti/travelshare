<html lang="en">
	<head>
		<meta charset="utf-8">
		<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
		<meta name="description" content="">
		<meta name="author" content="">

		<title><?php echo $main_title;?></title>
		
		<!-- JS -->
		<script src="<?php echo base_url('add_lib/js/jquery-1.10.2.min.js')?>"></script>
		<script src="<?php echo base_url('add_lib/js/bootstrap.min.js')?>"></script>
		
		<!-- CSS -->
		<link href="<?php echo base_url('add_lib/css/bootstrap.min.css')?>" rel="stylesheet">		
		<link href="<?php echo base_url('add_lib/css/mtr.css')?>" rel="stylesheet">		
		
	</head>

	<body>
		<div id="maincontent">
			<?php
				$this->load->view($main_header);
				$this->load->view($main_content);
				$this->load->view($main_footer);
			?>
		</div>
	</body>
</html>